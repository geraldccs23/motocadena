/*
  # RG7 Premios - Initial Schema Setup

  1. New Tables
    - `clientes` (clients)
      - `id` (uuid, primary key)
      - `nombre` (text, client name)
      - `telefono` (text, phone number)
      - `tiene_etiqueta` (boolean, has label/tag)
      - `created_at` (timestamptz, creation timestamp)
    
    - `productos` (products)
      - `id` (uuid, primary key)
      - `nombre` (text, product name)
      - `codigo` (text, product code)
      - `created_at` (timestamptz, creation timestamp)
    
    - `campanas` (campaigns)
      - `id` (uuid, primary key)
      - `nombre_campana` (text, campaign name)
      - `producto_asociado_id` (uuid, foreign key to productos)
      - `fecha_inicio` (date, start date)
      - `fecha_fin` (date, end date)
      - `estado` (text, status: Activa/Finalizada/Programada)
      - `created_at` (timestamptz, creation timestamp)
    
    - `entregas` (deliveries)
      - `id` (uuid, primary key)
      - `cliente_id` (uuid, foreign key to clientes)
      - `producto_id` (uuid, foreign key to productos)
      - `campana_id` (uuid, foreign key to campanas)
      - `fecha_entrega` (timestamptz, delivery timestamp)
      - `entregador` (text, deliverer name)
      - `created_at` (timestamptz, creation timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access (demo purposes)
    - Add policies for authenticated insert/update operations

  3. Notes
    - Schema designed for easy MySQL migration in the future
    - All tables use UUID for primary keys
    - Foreign keys ensure data integrity
*/

-- Create clientes table
CREATE TABLE IF NOT EXISTS clientes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  telefono text NOT NULL,
  tiene_etiqueta boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create productos table
CREATE TABLE IF NOT EXISTS productos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  codigo text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create campanas table
CREATE TABLE IF NOT EXISTS campanas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre_campana text NOT NULL,
  producto_asociado_id uuid REFERENCES productos(id) ON DELETE SET NULL,
  fecha_inicio date DEFAULT CURRENT_DATE,
  fecha_fin date,
  estado text DEFAULT 'Programada' CHECK (estado IN ('Activa', 'Finalizada', 'Programada')),
  created_at timestamptz DEFAULT now()
);

-- Create entregas table
CREATE TABLE IF NOT EXISTS entregas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id uuid REFERENCES clientes(id) ON DELETE CASCADE,
  producto_id uuid REFERENCES productos(id) ON DELETE SET NULL,
  campana_id uuid REFERENCES campanas(id) ON DELETE SET NULL,
  fecha_entrega timestamptz DEFAULT now(),
  entregador text DEFAULT 'Admin RG7',
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE productos ENABLE ROW LEVEL SECURITY;
ALTER TABLE campanas ENABLE ROW LEVEL SECURITY;
ALTER TABLE entregas ENABLE ROW LEVEL SECURITY;

-- Policies for clientes (allow public read for demo)
CREATE POLICY "Allow public read access to clientes"
  ON clientes FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert to clientes"
  ON clientes FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policies for productos
CREATE POLICY "Allow public read access to productos"
  ON productos FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert to productos"
  ON productos FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policies for campanas
CREATE POLICY "Allow public read access to campanas"
  ON campanas FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert to campanas"
  ON campanas FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public update to campanas"
  ON campanas FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

-- Policies for entregas
CREATE POLICY "Allow public read access to entregas"
  ON entregas FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert to entregas"
  ON entregas FOR INSERT
  TO anon
  WITH CHECK (true);

-- Insert mock data for productos
INSERT INTO productos (nombre, codigo) VALUES
  ('Filtro de Aire RG7', 'FAIR-001'),
  ('Gorra RG7', 'GORR-002')
ON CONFLICT (codigo) DO NOTHING;

-- Insert mock data for clientes
INSERT INTO clientes (nombre, telefono, tiene_etiqueta) VALUES
  ('Juan Pérez', '0412-1112233', true),
  ('María González', '0414-3344556', false),
  ('Carlos Ruiz', '0416-6677889', true),
  ('Ana Martínez', '0424-9988776', true),
  ('Pedro Silva', '0412-5544332', false),
  ('Sofía Ramírez', '0414-7766554', true)
ON CONFLICT DO NOTHING;

-- Insert mock data for campanas (will use producto ids)
INSERT INTO campanas (nombre_campana, producto_asociado_id, estado, fecha_inicio, fecha_fin)
SELECT 
  'Tu etiqueta, tu filtro',
  id,
  'Activa',
  CURRENT_DATE - INTERVAL '7 days',
  CURRENT_DATE + INTERVAL '30 days'
FROM productos WHERE codigo = 'FAIR-001'
ON CONFLICT DO NOTHING;

INSERT INTO campanas (nombre_campana, producto_asociado_id, estado, fecha_inicio, fecha_fin)
SELECT 
  'Tu compra, tu gorra',
  id,
  'Programada',
  CURRENT_DATE + INTERVAL '5 days',
  CURRENT_DATE + INTERVAL '60 days'
FROM productos WHERE codigo = 'GORR-002'
ON CONFLICT DO NOTHING;