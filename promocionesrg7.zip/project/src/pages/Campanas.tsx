import { useState, useEffect } from 'react';
import { Plus, Loader } from 'lucide-react';
import CampanaCard from '../components/CampanaCard';
import ModalNuevaCampana from '../components/ModalNuevaCampana';
import { Campana, Producto } from '../lib/supabase';
import {
  getCampanas,
  getProductos,
  crearCampana,
  actualizarEstadoCampana,
  getEntregasPorCampana,
} from '../services/api';

export default function Campanas() {
  const [campanas, setCampanas] = useState<Campana[]>([]);
  const [productos, setProductos] = useState<Producto[]>([]);
  const [entregas, setEntregas] = useState<Record<string, number>>({});
  const [mostrarModal, setMostrarModal] = useState(false);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    setCargando(true);
    try {
      const [campanasData, productosData] = await Promise.all([
        getCampanas(),
        getProductos(),
      ]);

      setCampanas(campanasData);
      setProductos(productosData);

      const entregasMap: Record<string, number> = {};
      for (const campana of campanasData) {
        const total = await getEntregasPorCampana(campana.id);
        entregasMap[campana.id] = total;
      }
      setEntregas(entregasMap);
    } catch (error) {
      console.error('Error cargando campañas:', error);
    } finally {
      setCargando(false);
    }
  };

  const handleCrearCampana = async (nuevaCampana: {
    nombre_campana: string;
    producto_asociado_id: string;
    fecha_inicio: string;
    fecha_fin: string;
    estado: string;
  }) => {
    try {
      await crearCampana(nuevaCampana);
      setMostrarModal(false);
      cargarDatos();
    } catch (error) {
      console.error('Error creando campaña:', error);
      alert('Error al crear la campaña');
    }
  };

  const handleToggleEstado = async (campanaId: string, nuevoEstado: string) => {
    try {
      await actualizarEstadoCampana(campanaId, nuevoEstado);
      cargarDatos();
    } catch (error) {
      console.error('Error actualizando estado:', error);
      alert('Error al actualizar el estado');
    }
  };

  if (cargando) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader className="w-8 h-8 text-[#FF2800] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {mostrarModal && (
        <ModalNuevaCampana
          productos={productos}
          onClose={() => setMostrarModal(false)}
          onCrear={handleCrearCampana}
        />
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Gestión de Campañas
          </h2>
          <p className="text-gray-400">
            Administra todas tus campañas promocionales
          </p>
        </div>

        <button
          onClick={() => setMostrarModal(true)}
          className="bg-[#FF2800] hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 flex items-center space-x-2 shadow-lg shadow-red-900/30 hover:shadow-red-900/50"
        >
          <Plus className="w-5 h-5" />
          <span>NUEVA CAMPAÑA</span>
        </button>
      </div>

      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Total Campañas</p>
            <p className="text-white font-bold text-2xl">{campanas.length}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Activas</p>
            <p className="text-green-400 font-bold text-2xl">
              {campanas.filter((c) => c.estado === 'Activa').length}
            </p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Programadas</p>
            <p className="text-yellow-400 font-bold text-2xl">
              {campanas.filter((c) => c.estado === 'Programada').length}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {campanas.map((campana) => {
          const producto = productos.find((p) => p.id === campana.producto_asociado_id);
          return (
            <CampanaCard
              key={campana.id}
              campana={campana}
              producto={producto}
              totalEntregas={entregas[campana.id] || 0}
              onToggleEstado={handleToggleEstado}
            />
          );
        })}
      </div>

      {campanas.length === 0 && (
        <div className="text-center py-12 bg-neutral-900 border border-neutral-800 rounded-lg">
          <p className="text-gray-500 text-lg mb-4">No hay campañas creadas</p>
          <button
            onClick={() => setMostrarModal(true)}
            className="bg-[#FF2800] hover:bg-red-700 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Crear primera campaña
          </button>
        </div>
      )}
    </div>
  );
}
