import { useState, useEffect } from 'react';
import { Search, Trophy, TrendingUp } from 'lucide-react';
import ClienteCard from '../components/ClienteCard';
import NotificacionExito from '../components/NotificacionExito';
import { Cliente, Campana, Producto } from '../lib/supabase';
import { getClientes, getCampanas, getProductos, registrarEntrega, getEntregas } from '../services/api';

export default function Premios() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [campanaActiva, setCampanaActiva] = useState<Campana | null>(null);
  const [productoActivo, setProductoActivo] = useState<Producto | null>(null);
  const [busqueda, setBusqueda] = useState('');
  const [notificacion, setNotificacion] = useState<string | null>(null);
  const [entregando, setEntregando] = useState(false);
  const [totalEntregas, setTotalEntregas] = useState(0);

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      const [clientesData, campanasData, productosData, entregasData] = await Promise.all([
        getClientes(),
        getCampanas(),
        getProductos(),
        getEntregas(),
      ]);

      setClientes(clientesData);
      setTotalEntregas(entregasData.length);

      const activa = campanasData.find((c) => c.estado === 'Activa');
      if (activa) {
        setCampanaActiva(activa);
        const prod = productosData.find((p) => p.id === activa.producto_asociado_id);
        setProductoActivo(prod || null);
      }
    } catch (error) {
      console.error('Error cargando datos:', error);
    }
  };

  const handleEntregarPremio = async (cliente: Cliente) => {
    if (!campanaActiva || !productoActivo || entregando) return;

    setEntregando(true);
    try {
      await registrarEntrega(cliente.id, productoActivo.id, campanaActiva.id);
      setNotificacion(`Premio entregado a ${cliente.nombre}`);
      setTotalEntregas((prev) => prev + 1);
    } catch (error) {
      console.error('Error al entregar premio:', error);
      alert('Error al registrar la entrega');
    } finally {
      setEntregando(false);
    }
  };

  const clientesFiltrados = clientes.filter(
    (cliente) =>
      cliente.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      cliente.telefono.includes(busqueda)
  );

  return (
    <div className="space-y-6">
      {notificacion && (
        <NotificacionExito
          mensaje={notificacion}
          onClose={() => setNotificacion(null)}
        />
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Módulo de Premios
          </h2>
          {campanaActiva && (
            <p className="text-gray-400">
              Campaña activa: <span className="text-[#FF2800] font-bold">{campanaActiva.nombre_campana}</span>
            </p>
          )}
        </div>

        <div className="flex items-center space-x-4">
          <div className="bg-gradient-to-r from-[#FF2800]/20 to-transparent p-4 rounded-lg border border-[#FF2800]/30">
            <div className="flex items-center space-x-3">
              <Trophy className="w-8 h-8 text-[#FF2800]" />
              <div>
                <p className="text-gray-400 text-xs uppercase">Total Entregas</p>
                <p className="text-white font-bold text-2xl">{totalEntregas}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {!campanaActiva && (
        <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4">
          <p className="text-yellow-400 font-bold">
            No hay campañas activas. Por favor, activa una campaña desde el módulo de Campañas.
          </p>
        </div>
      )}

      {campanaActiva && productoActivo && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-[#FF2800] p-2 rounded-lg">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Premio a entregar</p>
                <p className="text-white font-bold text-lg">{productoActivo.nombre}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
        <input
          type="text"
          placeholder="Buscar por nombre o teléfono..."
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
          className="w-full bg-neutral-900 border border-neutral-800 text-white rounded-lg pl-12 pr-4 py-4 focus:outline-none focus:border-[#FF2800] transition-colors"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {clientesFiltrados.map((cliente) => (
          <ClienteCard
            key={cliente.id}
            cliente={cliente}
            onEntregarPremio={handleEntregarPremio}
            disabled={entregando || !campanaActiva}
          />
        ))}
      </div>

      {clientesFiltrados.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No se encontraron clientes</p>
        </div>
      )}
    </div>
  );
}
