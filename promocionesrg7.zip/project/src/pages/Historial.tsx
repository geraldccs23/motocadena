import { useState, useEffect } from 'react';
import { Clock, User, Package, Calendar, Loader } from 'lucide-react';
import { EntregaDetalle } from '../lib/supabase';
import { getEntregas } from '../services/api';

export default function Historial() {
  const [entregas, setEntregas] = useState<EntregaDetalle[]>([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    cargarEntregas();
  }, []);

  const cargarEntregas = async () => {
    setCargando(true);
    try {
      const data = await getEntregas();
      setEntregas(data);
    } catch (error) {
      console.error('Error cargando entregas:', error);
    } finally {
      setCargando(false);
    }
  };

  const formatearFecha = (fecha: string) => {
    const date = new Date(fecha);
    return date.toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (cargando) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader className="w-8 h-8 text-[#FF2800] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Historial de Entregas
          </h2>
          <p className="text-gray-400">
            Registro completo de todos los premios entregados
          </p>
        </div>

        <div className="bg-gradient-to-r from-[#FF2800]/20 to-transparent p-4 rounded-lg border border-[#FF2800]/30">
          <div className="flex items-center space-x-3">
            <Package className="w-8 h-8 text-[#FF2800]" />
            <div>
              <p className="text-gray-400 text-xs uppercase">Total</p>
              <p className="text-white font-bold text-2xl">{entregas.length}</p>
            </div>
          </div>
        </div>
      </div>

      {entregas.length === 0 ? (
        <div className="text-center py-12 bg-neutral-900 border border-neutral-800 rounded-lg">
          <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">No hay entregas registradas</p>
        </div>
      ) : (
        <div className="space-y-4">
          {entregas.map((entrega, index) => (
            <div
              key={entrega.id}
              className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 hover:border-[#FF2800] transition-all duration-300 hover:shadow-lg hover:shadow-red-900/20"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="bg-[#FF2800] text-white font-bold w-12 h-12 rounded-lg flex items-center justify-center text-lg">
                    #{entregas.length - index}
                  </div>

                  <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <div className="flex items-center space-x-2 mb-1">
                        <User className="w-4 h-4 text-gray-500" />
                        <p className="text-gray-400 text-xs uppercase">Cliente</p>
                      </div>
                      <p className="text-white font-bold">
                        {entrega.clientes?.nombre || 'N/A'}
                      </p>
                      <p className="text-gray-400 text-sm">
                        {entrega.clientes?.telefono || 'N/A'}
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 mb-1">
                        <Package className="w-4 h-4 text-gray-500" />
                        <p className="text-gray-400 text-xs uppercase">Producto</p>
                      </div>
                      <p className="text-white font-bold">
                        {entrega.productos?.nombre || 'N/A'}
                      </p>
                      <p className="text-[#FF2800] text-sm font-medium">
                        {entrega.campanas?.nombre_campana || 'N/A'}
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 mb-1">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <p className="text-gray-400 text-xs uppercase">Fecha</p>
                      </div>
                      <p className="text-white font-bold">
                        {formatearFecha(entrega.fecha_entrega)}
                      </p>
                      <p className="text-gray-400 text-sm">
                        por {entrega.entregador}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-900/30 px-3 py-1 rounded-full border border-green-700 flex items-center space-x-1">
                  <Clock className="w-3 h-3 text-green-400" />
                  <span className="text-green-400 text-xs font-bold">ENTREGADO</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
