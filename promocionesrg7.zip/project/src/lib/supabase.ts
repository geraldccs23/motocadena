import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Cliente {
  id: string;
  nombre: string;
  telefono: string;
  tiene_etiqueta: boolean;
  created_at: string;
}

export interface Producto {
  id: string;
  nombre: string;
  codigo: string;
  created_at: string;
}

export interface Campana {
  id: string;
  nombre_campana: string;
  producto_asociado_id: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: 'Activa' | 'Finalizada' | 'Programada';
  created_at: string;
}

export interface Entrega {
  id: string;
  cliente_id: string;
  producto_id: string;
  campana_id: string;
  fecha_entrega: string;
  entregador: string;
  created_at: string;
}

export interface EntregaDetalle extends Entrega {
  clientes?: Cliente;
  productos?: Producto;
  campanas?: Campana;
}
