import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Premios from './pages/Premios';
import Campanas from './pages/Campanas';
import Historial from './pages/Historial';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Premios />} />
          <Route path="campanas" element={<Campanas />} />
          <Route path="historial" element={<Historial />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
