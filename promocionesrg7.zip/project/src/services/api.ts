import { supabase, Cliente, Producto, Campana, EntregaDetalle } from '../lib/supabase';

export const getClientes = async (): Promise<Cliente[]> => {
  const { data, error } = await supabase
    .from('clientes')
    .select('*')
    .order('nombre');

  if (error) throw error;
  return data || [];
};

export const getProductos = async (): Promise<Producto[]> => {
  const { data, error } = await supabase
    .from('productos')
    .select('*')
    .order('nombre');

  if (error) throw error;
  return data || [];
};

export const getCampanas = async (): Promise<Campana[]> => {
  const { data, error } = await supabase
    .from('campanas')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const getEntregas = async (): Promise<EntregaDetalle[]> => {
  const { data, error } = await supabase
    .from('entregas')
    .select(`
      *,
      clientes (nombre, telefono),
      productos (nombre, codigo),
      campanas (nombre_campana)
    `)
    .order('fecha_entrega', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const registrarEntrega = async (
  clienteId: string,
  productoId: string,
  campanaId: string
) => {
  const { data, error } = await supabase
    .from('entregas')
    .insert({
      cliente_id: clienteId,
      producto_id: productoId,
      campana_id: campanaId,
      entregador: 'Admin RG7',
      fecha_entrega: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const crearCampana = async (campana: {
  nombre_campana: string;
  producto_asociado_id: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: string;
}) => {
  const { data, error } = await supabase
    .from('campanas')
    .insert(campana)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const actualizarEstadoCampana = async (
  campanaId: string,
  estado: string
) => {
  const { data, error } = await supabase
    .from('campanas')
    .update({ estado })
    .eq('id', campanaId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getEntregasPorCampana = async (campanaId: string): Promise<number> => {
  const { count, error } = await supabase
    .from('entregas')
    .select('*', { count: 'exact', head: true })
    .eq('campana_id', campanaId);

  if (error) throw error;
  return count || 0;
};
