import { User, Phone, Tag, Gift } from 'lucide-react';
import { Cliente } from '../lib/supabase';

interface ClienteCardProps {
  cliente: Cliente;
  onEntregarPremio: (cliente: Cliente) => void;
  disabled?: boolean;
}

export default function ClienteCard({ cliente, onEntregarPremio, disabled }: ClienteCardProps) {
  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 hover:border-[#FF2800] transition-all duration-300 hover:shadow-lg hover:shadow-red-900/20">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-neutral-800 p-2 rounded-lg">
            <User className="w-5 h-5 text-[#FF2800]" />
          </div>
          <div>
            <h3 className="text-white font-bold text-lg">{cliente.nombre}</h3>
            <div className="flex items-center space-x-2 mt-1">
              <Phone className="w-3 h-3 text-gray-500" />
              <p className="text-gray-400 text-sm">{cliente.telefono}</p>
            </div>
          </div>
        </div>

        {cliente.tiene_etiqueta ? (
          <div className="flex items-center space-x-1 bg-green-900/30 px-3 py-1 rounded-full border border-green-700">
            <Tag className="w-3 h-3 text-green-400" />
            <span className="text-green-400 text-xs font-bold">CON ETIQUETA</span>
          </div>
        ) : (
          <div className="flex items-center space-x-1 bg-neutral-800 px-3 py-1 rounded-full border border-neutral-700">
            <Tag className="w-3 h-3 text-gray-500" />
            <span className="text-gray-500 text-xs font-bold">SIN ETIQUETA</span>
          </div>
        )}
      </div>

      {cliente.tiene_etiqueta ? (
        <button
          onClick={() => onEntregarPremio(cliente)}
          disabled={disabled}
          className="w-full bg-[#FF2800] hover:bg-red-700 disabled:bg-neutral-700 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2 shadow-lg shadow-red-900/30 hover:shadow-red-900/50 disabled:shadow-none"
        >
          <Gift className="w-4 h-4" />
          <span>ENTREGAR PREMIO</span>
        </button>
      ) : (
        <button
          disabled
          className="w-full bg-neutral-800 text-gray-500 font-bold py-3 px-4 rounded-lg cursor-not-allowed"
        >
          NO ELEGIBLE
        </button>
      )}
    </div>
  );
}
