import { CheckCircle, X } from 'lucide-react';
import { useEffect } from 'react';

interface NotificacionExitoProps {
  mensaje: string;
  onClose: () => void;
}

export default function NotificacionExito({ mensaje, onClose }: NotificacionExitoProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 4000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 z-50 animate-slide-in">
      <div className="bg-gradient-to-r from-green-900 to-green-800 border-2 border-green-600 rounded-lg shadow-2xl shadow-green-900/50 p-4 min-w-[320px] max-w-md">
        <div className="flex items-start space-x-3">
          <div className="bg-green-600 p-2 rounded-full">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-white font-bold text-lg mb-1">¡Premio Entregado!</p>
            <p className="text-green-200 text-sm">{mensaje}</p>
          </div>
          <button
            onClick={onClose}
            className="text-green-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
