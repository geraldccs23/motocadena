import { NavLink, Outlet } from 'react-router-dom';
import { Trophy, Flag, History } from 'lucide-react';

export default function Layout() {
  return (
    <div className="min-h-screen bg-black">
      <header className="bg-gradient-to-r from-black via-neutral-900 to-black border-b-4 border-[#FF2800] shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white tracking-tight">
                RG7 <span className="text-[#FF2800]">PREMIOS</span>
              </h1>
              <p className="text-gray-400 mt-1 text-sm font-medium">Sistema de Gestión de Campañas</p>
            </div>
            <div className="hidden md:flex items-center space-x-2 bg-neutral-900 px-4 py-2 rounded-lg border border-neutral-800">
              <div className="h-3 w-3 bg-[#FF2800] rounded-full animate-pulse"></div>
              <span className="text-white font-bold text-sm">SISTEMA ACTIVO</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex max-w-7xl mx-auto">
        <aside className="w-64 min-h-[calc(100vh-120px)] bg-neutral-900 border-r border-neutral-800">
          <nav className="p-4 space-y-2">
            <NavLink
              to="/"
              end
              className={({ isActive }) =>
                `flex items-center space-x-3 px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                  isActive
                    ? 'bg-[#FF2800] text-white shadow-lg shadow-red-900/50'
                    : 'text-gray-400 hover:bg-neutral-800 hover:text-white'
                }`
              }
            >
              <Trophy className="w-5 h-5" />
              <span>PREMIOS</span>
            </NavLink>

            <NavLink
              to="/campanas"
              className={({ isActive }) =>
                `flex items-center space-x-3 px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                  isActive
                    ? 'bg-[#FF2800] text-white shadow-lg shadow-red-900/50'
                    : 'text-gray-400 hover:bg-neutral-800 hover:text-white'
                }`
              }
            >
              <Flag className="w-5 h-5" />
              <span>CAMPAÑAS</span>
            </NavLink>

            <NavLink
              to="/historial"
              className={({ isActive }) =>
                `flex items-center space-x-3 px-4 py-3 rounded-lg font-bold text-sm transition-all ${
                  isActive
                    ? 'bg-[#FF2800] text-white shadow-lg shadow-red-900/50'
                    : 'text-gray-400 hover:bg-neutral-800 hover:text-white'
                }`
              }
            >
              <History className="w-5 h-5" />
              <span>HISTORIAL</span>
            </NavLink>
          </nav>

          <div className="p-4 mt-8">
            <div className="bg-gradient-to-br from-neutral-800 to-neutral-900 p-4 rounded-lg border border-neutral-700">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Información</p>
              <p className="text-white font-bold text-2xl mb-1">RG7</p>
              <p className="text-[#FF2800] text-xs font-medium">PERFORMANCE & PRECISION</p>
            </div>
          </div>
        </aside>

        <main className="flex-1 bg-neutral-950 p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
