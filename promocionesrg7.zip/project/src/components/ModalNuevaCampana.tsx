import { X, Plus } from 'lucide-react';
import { useState } from 'react';
import { Producto } from '../lib/supabase';

interface ModalNuevaCampanaProps {
  productos: Producto[];
  onClose: () => void;
  onCrear: (campana: {
    nombre_campana: string;
    producto_asociado_id: string;
    fecha_inicio: string;
    fecha_fin: string;
    estado: string;
  }) => void;
}

export default function ModalNuevaCampana({ productos, onClose, onCrear }: ModalNuevaCampanaProps) {
  const [formData, setFormData] = useState({
    nombre_campana: '',
    producto_asociado_id: '',
    fecha_inicio: new Date().toISOString().split('T')[0],
    fecha_fin: '',
    estado: 'Programada',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCrear(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-neutral-900 border-2 border-[#FF2800] rounded-lg shadow-2xl shadow-red-900/50 max-w-md w-full animate-fade-in">
        <div className="bg-gradient-to-r from-[#FF2800] to-red-700 p-6 rounded-t-lg flex items-center justify-between">
          <h2 className="text-white font-bold text-2xl">Nueva Campaña</h2>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 p-1 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="text-gray-400 text-sm font-bold mb-2 block">
              NOMBRE DE LA CAMPAÑA
            </label>
            <input
              type="text"
              required
              value={formData.nombre_campana}
              onChange={(e) => setFormData({ ...formData, nombre_campana: e.target.value })}
              className="w-full bg-neutral-800 border border-neutral-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-[#FF2800] transition-colors"
              placeholder="Ej: Tu compra, tu gorra"
            />
          </div>

          <div>
            <label className="text-gray-400 text-sm font-bold mb-2 block">
              PRODUCTO ASOCIADO
            </label>
            <select
              required
              value={formData.producto_asociado_id}
              onChange={(e) => setFormData({ ...formData, producto_asociado_id: e.target.value })}
              className="w-full bg-neutral-800 border border-neutral-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-[#FF2800] transition-colors"
            >
              <option value="">Seleccionar producto...</option>
              {productos.map((producto) => (
                <option key={producto.id} value={producto.id}>
                  {producto.nombre} ({producto.codigo})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-400 text-sm font-bold mb-2 block">
                FECHA INICIO
              </label>
              <input
                type="date"
                required
                value={formData.fecha_inicio}
                onChange={(e) => setFormData({ ...formData, fecha_inicio: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-[#FF2800] transition-colors"
              />
            </div>

            <div>
              <label className="text-gray-400 text-sm font-bold mb-2 block">
                FECHA FIN
              </label>
              <input
                type="date"
                required
                value={formData.fecha_fin}
                onChange={(e) => setFormData({ ...formData, fecha_fin: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-[#FF2800] transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-gray-400 text-sm font-bold mb-2 block">
              ESTADO INICIAL
            </label>
            <select
              value={formData.estado}
              onChange={(e) => setFormData({ ...formData, estado: e.target.value })}
              className="w-full bg-neutral-800 border border-neutral-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-[#FF2800] transition-colors"
            >
              <option value="Programada">Programada</option>
              <option value="Activa">Activa</option>
            </select>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-neutral-800 hover:bg-neutral-700 text-white font-bold py-3 px-4 rounded-lg transition-colors"
            >
              CANCELAR
            </button>
            <button
              type="submit"
              className="flex-1 bg-[#FF2800] hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2 shadow-lg shadow-red-900/30"
            >
              <Plus className="w-4 h-4" />
              <span>CREAR</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
