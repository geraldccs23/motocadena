import { Flag, Calendar, Package, Power, PowerOff } from 'lucide-react';
import { Campana, Producto } from '../lib/supabase';

interface CampanaCardProps {
  campana: Campana;
  producto?: Producto;
  totalEntregas: number;
  onToggleEstado: (campanaId: string, nuevoEstado: string) => void;
}

export default function CampanaCard({
  campana,
  producto,
  totalEntregas,
  onToggleEstado
}: CampanaCardProps) {
  const estadoColor = {
    Activa: 'bg-green-900/30 border-green-700 text-green-400',
    Finalizada: 'bg-red-900/30 border-red-700 text-red-400',
    Programada: 'bg-yellow-900/30 border-yellow-700 text-yellow-400',
  };

  const handleToggle = () => {
    const nuevoEstado = campana.estado === 'Activa' ? 'Finalizada' : 'Activa';
    onToggleEstado(campana.id, nuevoEstado);
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 hover:border-[#FF2800] transition-all duration-300 hover:shadow-lg hover:shadow-red-900/20">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-[#FF2800] p-2 rounded-lg">
            <Flag className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-bold text-xl">{campana.nombre_campana}</h3>
            {producto && (
              <div className="flex items-center space-x-2 mt-1">
                <Package className="w-3 h-3 text-gray-500" />
                <p className="text-gray-400 text-sm">{producto.nombre}</p>
              </div>
            )}
          </div>
        </div>

        <div className={`px-3 py-1 rounded-full border text-xs font-bold ${estadoColor[campana.estado]}`}>
          {campana.estado.toUpperCase()}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-neutral-800 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Calendar className="w-3 h-3 text-gray-500" />
            <p className="text-gray-500 text-xs uppercase">Inicio</p>
          </div>
          <p className="text-white font-bold text-sm">
            {new Date(campana.fecha_inicio).toLocaleDateString('es-ES')}
          </p>
        </div>

        <div className="bg-neutral-800 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Calendar className="w-3 h-3 text-gray-500" />
            <p className="text-gray-500 text-xs uppercase">Fin</p>
          </div>
          <p className="text-white font-bold text-sm">
            {new Date(campana.fecha_fin).toLocaleDateString('es-ES')}
          </p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-[#FF2800]/20 to-transparent p-4 rounded-lg border border-[#FF2800]/30 mb-4">
        <p className="text-gray-400 text-xs uppercase mb-1">Entregas totales</p>
        <p className="text-white font-bold text-3xl">{totalEntregas}</p>
      </div>

      {campana.estado !== 'Finalizada' && (
        <button
          onClick={handleToggle}
          className={`w-full font-bold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2 ${
            campana.estado === 'Activa'
              ? 'bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-700'
              : 'bg-green-900/30 hover:bg-green-900/50 text-green-400 border border-green-700'
          }`}
        >
          {campana.estado === 'Activa' ? (
            <>
              <PowerOff className="w-4 h-4" />
              <span>DESACTIVAR</span>
            </>
          ) : (
            <>
              <Power className="w-4 h-4" />
              <span>ACTIVAR</span>
            </>
          )}
        </button>
      )}
    </div>
  );
}
