export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          full_name: string
          username: string
          password: string
          role: 'admin' | 'mechanic' | 'receptionist'
          phone: string | null
          email: string | null
          status: 'active' | 'inactive'
          created_at: string
        }
        Insert: {
          id?: string
          full_name: string
          username: string
          password: string
          role: 'admin' | 'mechanic' | 'receptionist'
          phone?: string | null
          email?: string | null
          status?: 'active' | 'inactive'
          created_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          username?: string
          password?: string
          role?: 'admin' | 'mechanic' | 'receptionist'
          phone?: string | null
          email?: string | null
          status?: 'active' | 'inactive'
          created_at?: string
        }
      }
      clients: {
        Row: {
          id: string
          full_name: string
          phone: string
          vehicle_plate: string | null
          vehicle_brand: string | null
          vehicle_model: string | null
          created_at: string
        }
        Insert: {
          id?: string
          full_name: string
          phone: string
          vehicle_plate?: string | null
          vehicle_brand?: string | null
          vehicle_model?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          phone?: string
          vehicle_plate?: string | null
          vehicle_brand?: string | null
          vehicle_model?: string | null
          created_at?: string
        }
      }
      services: {
        Row: {
          id: string
          name: string
          description: string | null
          base_price: number
          duration_minutes: number | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          base_price?: number
          duration_minutes?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          base_price?: number
          duration_minutes?: number | null
          created_at?: string
        }
      }
      work_orders: {
        Row: {
          id: string
          client_id: string
          mechanic_id: string | null
          service_id: string
          status: 'pending' | 'in_progress' | 'completed' | 'cancelled'
          notes: string | null
          total: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          client_id: string
          mechanic_id?: string | null
          service_id: string
          status?: 'pending' | 'in_progress' | 'completed' | 'cancelled'
          notes?: string | null
          total?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          client_id?: string
          mechanic_id?: string | null
          service_id?: string
          status?: 'pending' | 'in_progress' | 'completed' | 'cancelled'
          notes?: string | null
          total?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
