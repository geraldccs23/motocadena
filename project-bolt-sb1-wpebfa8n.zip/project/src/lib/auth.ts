import { supabase } from './supabase';

export interface User {
  id: string;
  full_name: string;
  username: string;
  role: 'admin' | 'mechanic' | 'receptionist';
  phone: string | null;
  email: string | null;
  status: 'active' | 'inactive';
}

export async function loginUser(username: string, password: string): Promise<User | null> {
  const { data, error } = await supabase.rpc('login_user', {
    p_username: username,
    p_password: password
  });

  if (error) {
    console.error('Login error:', error);
    return null;
  }

  return data;
}

export async function getCurrentUser(): Promise<User | null> {
  const userStr = localStorage.getItem('motocadena_user');
  if (!userStr) return null;

  try {
    return JSON.parse(userStr);
  } catch {
    return null;
  }
}

export function saveUser(user: User): void {
  localStorage.setItem('motocadena_user', JSON.stringify(user));
}

export function clearUser(): void {
  localStorage.removeItem('motocadena_user');
}

export function isAdmin(user: User | null): boolean {
  return user?.role === 'admin';
}

export function isMechanic(user: User | null): boolean {
  return user?.role === 'mechanic';
}

export function isReceptionist(user: User | null): boolean {
  return user?.role === 'receptionist';
}
