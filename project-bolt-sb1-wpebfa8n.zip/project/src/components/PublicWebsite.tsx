import { useState, useEffect } from 'react';
import { Wrench, Phone, Mail, MapPin, Clock, DollarSign, Zap, Shield, Award, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Service = Database['public']['Tables']['services']['Row'];

interface PublicWebsiteProps {
  onNavigateToPanel: () => void;
}

export default function PublicWebsite({ onNavigateToPanel }: PublicWebsiteProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    vehicle_brand: '',
    vehicle_model: '',
    service_id: '',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .order('base_price');

      if (error) throw error;
      setServices(data || []);
    } catch (error) {
      console.error('Error loading services:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');

    try {
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .insert([{
          full_name: formData.full_name,
          phone: formData.phone,
          vehicle_brand: formData.vehicle_brand,
          vehicle_model: formData.vehicle_model
        }])
        .select()
        .single();

      if (clientError) throw clientError;

      const service = services.find(s => s.id === formData.service_id);
      if (!service) throw new Error('Servicio no encontrado');

      const { error: orderError } = await supabase
        .from('work_orders')
        .insert([{
          client_id: clientData.id,
          service_id: formData.service_id,
          notes: formData.notes,
          total: service.base_price,
          status: 'pending'
        }]);

      if (orderError) throw orderError;

      setSubmitMessage('¡Solicitud enviada con éxito! Nos pondremos en contacto contigo pronto.');
      setFormData({
        full_name: '',
        phone: '',
        vehicle_brand: '',
        vehicle_model: '',
        service_id: '',
        notes: ''
      });
    } catch (error) {
      console.error('Error submitting request:', error);
      setSubmitMessage('Error al enviar la solicitud. Por favor, intenta de nuevo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen concrete-texture">
      <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-neutral-950/80 border-b border-amber-600/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Wrench className="w-10 h-10 text-amber-500" />
              <div>
                <h1 className="text-3xl font-bold heading-racing text-amber-500">MOTOCADENA</h1>
                <p className="text-xs text-neutral-400 uppercase tracking-widest">Taller Profesional</p>
              </div>
            </div>
            <button
              onClick={onNavigateToPanel}
              className="btn-metal text-sm flex items-center gap-2"
            >
              ÁREA DE OPERACIONES
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <section className="pt-32 pb-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-amber-900/20 via-transparent to-transparent"></div>
        <div className="absolute top-20 left-10 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-10 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl"></div>

        <div className="container mx-auto text-center relative z-10">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="absolute inset-0 blur-2xl bg-amber-500/30 animate-pulse"></div>
              <Wrench className="w-32 h-32 text-amber-500 relative" strokeWidth={1.5} />
            </div>
          </div>

          <h2 className="text-7xl md:text-8xl font-bold heading-racing text-amber-500 mb-6 text-glow">
            MOTOCADENA
          </h2>
          <p className="text-3xl md:text-4xl text-neutral-300 mb-4 text-racing">
            LA CADENA QUE MUEVE TU MOTOR
          </p>
          <div className="h-1 w-64 mx-auto gold-gradient mb-8"></div>
          <p className="text-xl text-neutral-400 max-w-2xl mx-auto">
            Taller especializado en reparación y mantenimiento de motocicletas.
            Servicio profesional, calidad garantizada y pasión por las dos ruedas.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mt-12">
            <a href="#servicios" className="btn-gold text-lg">
              VER SERVICIOS
            </a>
            <a href="#contacto" className="btn-metal text-lg">
              CONTACTO
            </a>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-neutral-900/50">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card-metal p-8 text-center hover:scale-105 transition-transform duration-200">
              <Zap className="w-16 h-16 text-amber-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold heading-racing text-neutral-100 mb-2">RAPIDEZ</h3>
              <p className="text-neutral-400">Servicio eficiente sin comprometer la calidad</p>
            </div>

            <div className="card-metal p-8 text-center hover:scale-105 transition-transform duration-200">
              <Shield className="w-16 h-16 text-amber-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold heading-racing text-neutral-100 mb-2">GARANTÍA</h3>
              <p className="text-neutral-400">Respaldamos nuestro trabajo con garantía total</p>
            </div>

            <div className="card-metal p-8 text-center hover:scale-105 transition-transform duration-200">
              <Award className="w-16 h-16 text-amber-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold heading-racing text-neutral-100 mb-2">EXPERIENCIA</h3>
              <p className="text-neutral-400">Años de experiencia en el mundo motero</p>
            </div>
          </div>
        </div>
      </section>

      <section id="servicios" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold heading-racing text-amber-500 mb-4">
              NUESTROS SERVICIOS
            </h2>
            <div className="h-1 w-48 mx-auto gold-gradient mb-6"></div>
            <p className="text-xl text-neutral-400">
              Servicios especializados para mantener tu moto en perfectas condiciones
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <div key={service.id} className="card-metal p-6 hover:brightness-110 transition-all duration-200 group">
                <div className="flex items-start justify-between mb-4">
                  <Wrench className="w-10 h-10 text-amber-500 group-hover:rotate-12 transition-transform duration-200" />
                  <div className="flex items-center gap-2 text-amber-400">
                    <DollarSign className="w-5 h-5" />
                    <span className="text-2xl font-bold">{service.base_price.toFixed(2)}</span>
                  </div>
                </div>

                <h3 className="text-2xl font-bold heading-racing text-neutral-100 mb-3">
                  {service.name}
                </h3>

                {service.description && (
                  <p className="text-neutral-400 mb-4">{service.description}</p>
                )}

                <div className="flex items-center gap-2 text-neutral-500 text-sm">
                  <Clock className="w-4 h-4" />
                  <span>{service.duration_minutes} minutos aprox.</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="agendar" className="py-20 px-4 bg-neutral-900/50">
        <div className="container mx-auto max-w-3xl">
          <div className="text-center mb-12">
            <h2 className="text-5xl md:text-6xl font-bold heading-racing text-amber-500 mb-4">
              AGENDA TU SERVICIO
            </h2>
            <div className="h-1 w-48 mx-auto gold-gradient mb-6"></div>
            <p className="text-xl text-neutral-400">
              Completa el formulario y nos pondremos en contacto contigo
            </p>
          </div>

          <div className="card-metal p-8">
            {submitMessage && (
              <div className={`p-4 rounded mb-6 text-center font-semibold ${
                submitMessage.includes('éxito')
                  ? 'bg-green-900/30 border border-green-500/50 text-green-300'
                  : 'bg-red-900/30 border border-red-500/50 text-red-300'
              }`}>
                {submitMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                    Nombre Completo *
                  </label>
                  <input
                    type="text"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    className="input-metal w-full"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                    Teléfono *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="input-metal w-full"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                    Marca de Moto
                  </label>
                  <input
                    type="text"
                    value={formData.vehicle_brand}
                    onChange={(e) => setFormData({ ...formData, vehicle_brand: e.target.value })}
                    className="input-metal w-full"
                    placeholder="Ej: Honda, Yamaha..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                    Modelo
                  </label>
                  <input
                    type="text"
                    value={formData.vehicle_model}
                    onChange={(e) => setFormData({ ...formData, vehicle_model: e.target.value })}
                    className="input-metal w-full"
                    placeholder="Ej: CBR 600RR"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Servicio Requerido *
                </label>
                <select
                  value={formData.service_id}
                  onChange={(e) => setFormData({ ...formData, service_id: e.target.value })}
                  className="input-metal w-full"
                  required
                >
                  <option value="">Seleccionar servicio...</option>
                  {services.map(service => (
                    <option key={service.id} value={service.id}>
                      {service.name} - ${service.base_price.toFixed(2)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Detalles Adicionales
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="input-metal w-full h-24 resize-none"
                  placeholder="Describe el problema o servicio que necesitas..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn-gold text-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'ENVIANDO...' : 'ENVIAR SOLICITUD'}
              </button>
            </form>
          </div>
        </div>
      </section>

      <section id="contacto" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-5xl md:text-6xl font-bold heading-racing text-amber-500 mb-4">
              CONTACTO
            </h2>
            <div className="h-1 w-48 mx-auto gold-gradient"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card-metal p-8 text-center">
              <Phone className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold heading-racing text-neutral-100 mb-2">TELÉFONO</h3>
              <p className="text-neutral-400">+506 8888-8888</p>
              <p className="text-neutral-400">+506 7777-7777</p>
            </div>

            <div className="card-metal p-8 text-center">
              <MapPin className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold heading-racing text-neutral-100 mb-2">UBICACIÓN</h3>
              <p className="text-neutral-400">San José, Costa Rica</p>
              <p className="text-neutral-400">200m norte de la iglesia</p>
            </div>

            <div className="card-metal p-8 text-center">
              <Clock className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold heading-racing text-neutral-100 mb-2">HORARIO</h3>
              <p className="text-neutral-400">Lunes a Viernes: 8am - 6pm</p>
              <p className="text-neutral-400">Sábados: 8am - 2pm</p>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-8 px-4 border-t border-amber-600/20 bg-neutral-950">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Wrench className="w-8 h-8 text-amber-500" />
            <h3 className="text-2xl font-bold heading-racing text-amber-500">MOTOCADENA</h3>
          </div>
          <p className="text-neutral-500 text-sm uppercase tracking-wider">
            La Cadena que Mueve tu Motor
          </p>
          <p className="text-neutral-600 text-xs mt-4">
            © 2025 Motocadena. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}
