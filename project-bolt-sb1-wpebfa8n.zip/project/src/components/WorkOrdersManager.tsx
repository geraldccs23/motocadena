import { useState, useEffect } from 'react';
import { Plus, Edit2, Check, X, FileText, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';
import type { User } from '../lib/auth';

type WorkOrder = Database['public']['Tables']['work_orders']['Row'];
type Client = Database['public']['Tables']['clients']['Row'];
type Service = Database['public']['Tables']['services']['Row'];
type Mechanic = Database['public']['Tables']['users']['Row'];

interface WorkOrderWithRelations extends WorkOrder {
  client: Client | null;
  service: Service | null;
  mechanic: Mechanic | null;
}

interface WorkOrdersManagerProps {
  user: User;
  onStatsUpdate: () => void;
}

const statusConfig = {
  pending: { label: 'Pendiente', color: 'bg-yellow-900/30 text-yellow-400 border-yellow-800/50' },
  in_progress: { label: 'En Proceso', color: 'bg-blue-900/30 text-blue-400 border-blue-800/50' },
  completed: { label: 'Completado', color: 'bg-green-900/30 text-green-400 border-green-800/50' },
  cancelled: { label: 'Cancelado', color: 'bg-red-900/30 text-red-400 border-red-800/50' }
};

export default function WorkOrdersManager({ user, onStatsUpdate }: WorkOrdersManagerProps) {
  const [orders, setOrders] = useState<WorkOrderWithRelations[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [mechanics, setMechanics] = useState<Mechanic[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingOrder, setEditingOrder] = useState<WorkOrderWithRelations | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [formData, setFormData] = useState({
    client_id: '',
    service_id: '',
    mechanic_id: '',
    notes: '',
    total: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [ordersResult, clientsResult, servicesResult, mechanicsResult] = await Promise.all([
        supabase
          .from('work_orders')
          .select(`
            *,
            client:clients(*),
            service:services(*),
            mechanic:users(*)
          `)
          .order('created_at', { ascending: false }),
        supabase.from('clients').select('*').order('full_name'),
        supabase.from('services').select('*').order('name'),
        supabase.from('users').select('*').eq('role', 'mechanic').eq('status', 'active')
      ]);

      if (ordersResult.error) throw ordersResult.error;
      if (clientsResult.error) throw clientsResult.error;
      if (servicesResult.error) throw servicesResult.error;
      if (mechanicsResult.error) throw mechanicsResult.error;

      setOrders(ordersResult.data as WorkOrderWithRelations[] || []);
      setClients(clientsResult.data || []);
      setServices(servicesResult.data || []);
      setMechanics(mechanicsResult.data || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const orderData = {
        client_id: formData.client_id,
        service_id: formData.service_id,
        mechanic_id: formData.mechanic_id || null,
        notes: formData.notes,
        total: parseFloat(formData.total),
        status: editingOrder?.status || 'pending'
      };

      if (editingOrder) {
        const { error } = await supabase
          .from('work_orders')
          .update({ ...orderData, updated_at: new Date().toISOString() })
          .eq('id', editingOrder.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('work_orders')
          .insert([orderData]);

        if (error) throw error;
      }

      setShowModal(false);
      resetForm();
      loadData();
      onStatsUpdate();
    } catch (error) {
      console.error('Error saving order:', error);
      alert('Error al guardar la orden');
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('work_orders')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', orderId);

      if (error) throw error;
      loadData();
      onStatsUpdate();
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Error al actualizar el estado');
    }
  };

  const handleEdit = (order: WorkOrderWithRelations) => {
    setEditingOrder(order);
    setFormData({
      client_id: order.client_id,
      service_id: order.service_id,
      mechanic_id: order.mechanic_id || '',
      notes: order.notes || '',
      total: order.total.toString()
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      client_id: '',
      service_id: '',
      mechanic_id: '',
      notes: '',
      total: ''
    });
    setEditingOrder(null);
  };

  const handleServiceChange = (serviceId: string) => {
    setFormData({ ...formData, service_id: serviceId });
    const service = services.find(s => s.id === serviceId);
    if (service && !formData.total) {
      setFormData(prev => ({ ...prev, total: service.base_price.toString(), service_id: serviceId }));
    }
  };

  const filteredOrders = filterStatus === 'all'
    ? orders
    : orders.filter(order => order.status === filterStatus);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-4xl font-bold heading-racing text-neutral-100 mb-2">ÓRDENES DE TRABAJO</h2>
          <p className="text-neutral-400 text-racing">Gestión de servicios y reparaciones</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="btn-gold flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          NUEVA ORDEN
        </button>
      </div>

      <div className="card-metal p-4 mb-6">
        <div className="flex gap-2 overflow-x-auto">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded text-sm font-semibold uppercase tracking-wide transition-all ${
              filterStatus === 'all' ? 'btn-gold' : 'btn-metal'
            }`}
          >
            Todas ({orders.length})
          </button>
          {Object.entries(statusConfig).map(([status, config]) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-4 py-2 rounded text-sm font-semibold uppercase tracking-wide transition-all whitespace-nowrap ${
                filterStatus === status ? config.color + ' border' : 'btn-metal'
              }`}
            >
              {config.label} ({orders.filter(o => o.status === status).length})
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="card-metal p-12 text-center">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="card-metal p-12 text-center">
          <p className="text-neutral-400">No hay órdenes de trabajo</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div key={order.id} className="card-metal p-6 hover:brightness-110 transition-all duration-200">
              <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-neutral-100 mb-1">
                        {order.client?.full_name || 'Cliente desconocido'}
                      </h3>
                      <p className="text-amber-400 font-semibold">
                        {order.service?.name || 'Servicio desconocido'}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded text-sm font-semibold uppercase tracking-wide border ${statusConfig[order.status].color}`}>
                      {statusConfig[order.status].label}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-neutral-400">
                    {order.mechanic && (
                      <div>
                        <span className="text-neutral-500">Mecánico:</span>{' '}
                        <span className="text-neutral-200">{order.mechanic.full_name}</span>
                      </div>
                    )}
                    <div>
                      <span className="text-neutral-500">Total:</span>{' '}
                      <span className="text-amber-400 font-semibold">${order.total.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {new Date(order.created_at).toLocaleDateString()} {new Date(order.created_at).toLocaleTimeString()}
                    </div>
                  </div>

                  {order.notes && (
                    <div className="mt-3 p-3 bg-neutral-900/50 rounded border border-neutral-700/50">
                      <div className="flex items-start gap-2">
                        <FileText className="w-4 h-4 text-neutral-500 mt-0.5" />
                        <p className="text-sm text-neutral-300">{order.notes}</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex lg:flex-col gap-2">
                  <button
                    onClick={() => handleEdit(order)}
                    className="p-2 bg-blue-900/30 text-blue-400 rounded hover:bg-blue-900/50 transition-colors"
                    title="Editar"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>

                  {order.status === 'pending' && (
                    <button
                      onClick={() => handleStatusChange(order.id, 'in_progress')}
                      className="p-2 bg-blue-900/30 text-blue-400 rounded hover:bg-blue-900/50 transition-colors"
                      title="Iniciar"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}

                  {order.status === 'in_progress' && (
                    <button
                      onClick={() => handleStatusChange(order.id, 'completed')}
                      className="p-2 bg-green-900/30 text-green-400 rounded hover:bg-green-900/50 transition-colors"
                      title="Completar"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}

                  {(order.status === 'pending' || order.status === 'in_progress') && (
                    <button
                      onClick={() => handleStatusChange(order.id, 'cancelled')}
                      className="p-2 bg-red-900/30 text-red-400 rounded hover:bg-red-900/50 transition-colors"
                      title="Cancelar"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="card-metal p-8 max-w-2xl w-full my-8">
            <h3 className="text-2xl font-bold heading-racing text-neutral-100 mb-6">
              {editingOrder ? 'EDITAR ORDEN' : 'NUEVA ORDEN'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Cliente *
                </label>
                <select
                  value={formData.client_id}
                  onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
                  className="input-metal w-full"
                  required
                >
                  <option value="">Seleccionar cliente...</option>
                  {clients.map(client => (
                    <option key={client.id} value={client.id}>
                      {client.full_name} - {client.phone}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Servicio *
                </label>
                <select
                  value={formData.service_id}
                  onChange={(e) => handleServiceChange(e.target.value)}
                  className="input-metal w-full"
                  required
                >
                  <option value="">Seleccionar servicio...</option>
                  {services.map(service => (
                    <option key={service.id} value={service.id}>
                      {service.name} - ${service.base_price.toFixed(2)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Mecánico Asignado
                </label>
                <select
                  value={formData.mechanic_id}
                  onChange={(e) => setFormData({ ...formData, mechanic_id: e.target.value })}
                  className="input-metal w-full"
                >
                  <option value="">Sin asignar</option>
                  {mechanics.map(mechanic => (
                    <option key={mechanic.id} value={mechanic.id}>
                      {mechanic.full_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Total *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.total}
                  onChange={(e) => setFormData({ ...formData, total: e.target.value })}
                  className="input-metal w-full"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                  Notas
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="input-metal w-full h-24 resize-none"
                  placeholder="Observaciones, detalles adicionales..."
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button type="submit" className="btn-gold flex-1">
                  {editingOrder ? 'ACTUALIZAR' : 'CREAR ORDEN'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-metal flex-1"
                >
                  CANCELAR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
