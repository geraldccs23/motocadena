/*
  # Add Login Function

  ## Overview
  Creates a PostgreSQL function to handle user authentication by validating
  username and password credentials using bcrypt hashing.

  ## Function Created
  - `login_user(p_username text, p_password text)`
    - Validates user credentials
    - Returns user data if authentication successful
    - Returns NULL if authentication fails
    - Checks that user status is 'active'

  ## Security
  - Uses pgcrypto extension for password verification
  - Does not expose password hashes
  - Only returns data for active users
*/

CREATE OR REPLACE FUNCTION login_user(p_username text, p_password text)
RETURNS TABLE (
  id uuid,
  full_name text,
  username text,
  role text,
  phone text,
  email text,
  status text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    u.id,
    u.full_name,
    u.username,
    u.role,
    u.phone,
    u.email,
    u.status
  FROM users u
  WHERE u.username = p_username
    AND u.password = crypt(p_password, u.password)
    AND u.status = 'active'
  LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
