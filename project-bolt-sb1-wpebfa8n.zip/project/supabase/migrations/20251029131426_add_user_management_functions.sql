/*
  # Add User Management Functions

  ## Overview
  Creates PostgreSQL functions to handle user creation and password updates
  with proper bcrypt hashing.

  ## Functions Created

  1. `create_user` - Creates a new user with hashed password
     - Parameters: full_name, username, password, role, phone, email
     - Returns: void
     - Hashes password using bcrypt before insertion

  2. `update_user_password` - Updates user password with proper hashing
     - Parameters: user_id, new_password
     - Returns: void
     - Updates password hash for existing user

  ## Security
  - Uses SECURITY DEFINER to allow execution with elevated privileges
  - Validates user exists before password update
  - Uses pgcrypto for secure password hashing
*/

CREATE OR REPLACE FUNCTION create_user(
  p_full_name text,
  p_username text,
  p_password text,
  p_role text,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  INSERT INTO users (full_name, username, password, role, phone, email, status)
  VALUES (
    p_full_name,
    p_username,
    crypt(p_password, gen_salt('bf')),
    p_role,
    p_phone,
    p_email,
    'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_user_password(
  user_id uuid,
  new_password text
)
RETURNS void AS $$
BEGIN
  UPDATE users
  SET password = crypt(new_password, gen_salt('bf'))
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
