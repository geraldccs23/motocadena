/*
  # MOTOCADENA Database Schema

  ## Overview
  Complete database schema for MOTOCADENA motorcycle workshop management system.
  Includes user authentication, client management, service catalog, and work order tracking.

  ## Tables Created

  ### 1. users
  - `id` (uuid, primary key) - Unique user identifier
  - `full_name` (text) - Full name of the user
  - `username` (text, unique) - Login username
  - `password` (text) - Hashed password
  - `role` (text) - User role: 'admin', 'mechanic', 'receptionist'
  - `phone` (text) - Contact phone number
  - `email` (text) - Email address
  - `status` (text) - Account status: 'active' or 'inactive'
  - `created_at` (timestamptz) - Account creation timestamp

  ### 2. clients
  - `id` (uuid, primary key) - Unique client identifier
  - `full_name` (text) - Client's full name
  - `phone` (text) - Contact phone number
  - `vehicle_plate` (text) - Motorcycle license plate
  - `vehicle_brand` (text) - Motorcycle brand (Honda, Yamaha, etc.)
  - `vehicle_model` (text) - Motorcycle model
  - `created_at` (timestamptz) - Registration timestamp

  ### 3. services
  - `id` (uuid, primary key) - Unique service identifier
  - `name` (text) - Service name
  - `description` (text) - Detailed service description
  - `base_price` (numeric) - Base price in local currency
  - `duration_minutes` (integer) - Estimated duration in minutes
  - `created_at` (timestamptz) - Service creation timestamp

  ### 4. work_orders
  - `id` (uuid, primary key) - Unique work order identifier
  - `client_id` (uuid, foreign key) - References clients table
  - `mechanic_id` (uuid, foreign key) - References users table
  - `service_id` (uuid, foreign key) - References services table
  - `status` (text) - Order status: 'pending', 'in_progress', 'completed', 'cancelled'
  - `notes` (text) - Additional notes and observations
  - `total` (numeric) - Final total amount
  - `created_at` (timestamptz) - Order creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Policies configured for role-based access control
  - Admin users have full access
  - Mechanics can view and update their assigned orders
  - Receptionists can manage clients and create orders

  ## Important Notes
  - All IDs use UUID for security and scalability
  - Timestamps use timestamptz for timezone awareness
  - Default admin user created: username 'admin', password 'Motocadena2025!'
  - Passwords are stored hashed using crypt extension
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name text NOT NULL,
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'mechanic', 'receptionist')),
  phone text,
  email text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now()
);

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name text NOT NULL,
  phone text NOT NULL,
  vehicle_plate text,
  vehicle_brand text,
  vehicle_model text,
  created_at timestamptz DEFAULT now()
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  base_price numeric(10, 2) NOT NULL DEFAULT 0,
  duration_minutes integer DEFAULT 60,
  created_at timestamptz DEFAULT now()
);

-- Create work_orders table
CREATE TABLE IF NOT EXISTS work_orders (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  mechanic_id uuid REFERENCES users(id) ON DELETE SET NULL,
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  notes text,
  total numeric(10, 2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_work_orders_client ON work_orders(client_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_mechanic ON work_orders(mechanic_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_created ON work_orders(created_at DESC);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_orders ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can view all users"
  ON users FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can insert users"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can update users"
  ON users FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete users"
  ON users FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for clients table
CREATE POLICY "Authenticated users can view clients"
  ON clients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Only admins can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for services table
CREATE POLICY "Everyone can view services"
  ON services FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can insert services"
  ON services FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can update services"
  ON services FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete services"
  ON services FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for work_orders table
CREATE POLICY "Authenticated users can view work orders"
  ON work_orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create work orders"
  ON work_orders FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update work orders"
  ON work_orders FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Only admins can delete work orders"
  ON work_orders FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Insert default admin user (password: Motocadena2025!)
INSERT INTO users (full_name, username, password, role, email, status)
VALUES (
  'Administrador',
  'admin',
  crypt('Motocadena2025!', gen_salt('bf')),
  'admin',
  'admin@motocadena.com',
  'active'
) ON CONFLICT (username) DO NOTHING;

-- Insert sample services
INSERT INTO services (name, description, base_price, duration_minutes) VALUES
  ('Cambio de Aceite', 'Cambio de aceite y filtro completo', 150.00, 30),
  ('Mantenimiento Básico', 'Revisión general, ajuste de cadena, frenos y luces', 250.00, 60),
  ('Cambio de Llantas', 'Instalación de llantas nuevas (no incluye llantas)', 200.00, 45),
  ('Ajuste de Motor', 'Sincronización y ajuste de carburador o inyección', 350.00, 90),
  ('Reparación de Frenos', 'Cambio de pastillas y revisión del sistema de frenos', 180.00, 40),
  ('Limpieza de Carburador', 'Desmontaje, limpieza y ajuste de carburador', 220.00, 75)
ON CONFLICT DO NOTHING;