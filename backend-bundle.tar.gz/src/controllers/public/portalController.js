const { supabase } = require('../../services/supabaseClient');

function makeError(status, message, code = 'BAD_REQUEST') {
  const e = new Error(message);
  e.status = status;
  e.code = code;
  return e;
}

exports.loginAndFetch = async (req, res, next) => {
  try {
    const { phone, id_number } = req.body;
    if (!phone) throw makeError(400, 'Número de celular es requerido');

    // 1. Encontrar cliente (normalizando espacios)
    let query = supabase.from('customers').select('*').eq('phone', phone.trim());
    if (id_number && id_number.trim() !== '') {
       query = query.eq('id_number', id_number.trim());
    }

    const { data: customers, error: cErr } = await query;
    if (cErr) throw makeError(500, cErr.message);
    if (!customers || customers.length === 0) {
      throw makeError(404, 'No hemos encontrado un piloto con estas credenciales. Verifica tus datos.');
    }

    const customer = customers[0];

    // 2. Traer las motos asociadas (Vehicles)
    const { data: vehicles } = await supabase.from('vehicles')
      .select('*')
      .eq('owner_id', customer.id);

    // 3. Traer las Ordenes de trabajo (Work Orders)
    const { data: workOrders } = await supabase.from('work_orders')
      .select('*, vehicle:vehicles(*)')
      .eq('customer_id', customer.id)
      .order('created_at', { ascending: false });

    // 4. Traer Historial de Citas (Appointments)
    const { data: appointments } = await supabase.from('appointments')
      .select('*, vehicle:vehicles(*), service:services(*)')
      .eq('customer_id', customer.id)
      .order('appointment_date', { ascending: false });

    // 5. Send secure snapshot directly to client.
    res.json({
      ok: true,
      customer: {
        id: customer.id,
        first_name: customer.first_name,
        last_name: customer.last_name,
        phone: customer.phone,
        email: customer.email,
        id_number: customer.id_number
      },
      vehicles: vehicles || [],
      workOrders: workOrders || [],
      appointments: appointments || []
    });

  } catch (err) { next(err); }
};
