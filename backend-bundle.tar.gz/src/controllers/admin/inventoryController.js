const { supabase } = require('../../services/supabaseClient');

function makeError(status, message, code = 'BAD_REQUEST') {
  const e = new Error(message);
  e.status = status;
  e.code = code;
  return e;
}

exports.movements = async (req, res, next) => {
  try {
    const { data, error } = await supabase.from('inventory_movements').select('*').order('created_at', { ascending: false });
    if (error) throw makeError(500, error.message);
    res.json(data);
  } catch (err) { next(err); }
};

exports.stock = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;

    // 1. Fetch from the view with range for pagination
    const { data, error, count } = await supabase
      .from('v_products_with_stock')
      .select('*', { count: 'exact' })
      .order('name')
      .range(offset, offset + limit - 1);

    if (error) throw makeError(500, error.message);

    // 2. Map to the format expected by the frontend
    const result = data.map(p => ({
      product_id: p.id,
      sku: p.sku,
      name: p.name,
      unit_price: p.unit_price,
      unit_cost: p.unit_cost,
      status: p.status,
      stock: Number(p.stock) || 0
    }));

    res.json({
      stock: result,
      pagination: {
        totalItems: count,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        limit
      }
    });
  } catch (err) { next(err); }
};

exports.stockByProduct = async (req, res, next) => {
  try {
    const productId = req.params.productId;
    const { data, error } = await supabase
      .from('inventory_movements')
      .select('movement_type, quantity')
      .eq('product_id', productId);
    if (error) throw makeError(500, error.message);
    let stock = 0;
    for (const m of data || []) {
      if (m.movement_type === 'in') stock += Number(m.quantity);
      else if (m.movement_type === 'out') stock -= Number(m.quantity);
    }
    res.json({ product_id: productId, stock });
  } catch (err) { next(err); }
};

exports.adjust = async (req, res, next) => {
  try {
    const { product_id, warehouse_id, movement_type, quantity, unit_cost, source, source_id, notes } = req.body;
    if (!product_id || !movement_type || !quantity) {
      throw makeError(400, 'product_id, movement_type, quantity son requeridos');
    }

    // Usaremos el RPC para actualizar atómicamente el stock para prevenir condiciones de carrera
    let wId = warehouse_id;
    if (!wId) {
      const { data: wh } = await supabase.from('warehouses').select('id').limit(1).single();
      if (!wh) throw makeError(400, 'No existe un almacén y no fue proveído');
      wId = wh.id;
    }

    const { data: rpcData, error: rpcError } = await supabase.rpc('process_inventory_movement', {
      p_product_id: product_id,
      p_warehouse_id: wId,
      p_movement_type: movement_type.toLowerCase(),
      p_quantity: quantity,
      p_notes: notes || null
    });

    if (rpcError) throw makeError(500, 'Error atómico ajustando inventario: ' + rpcError.message);
    
    // Si queremos preservar compatibilidad con cosas que esperan el unit_cost/source lo inyectamos de vuelta (opcional manual o modificar RPC)
    // Pero la vista ya está actualizada correctamente.
    
    res.status(201).json({ ok: true, new_stock: rpcData?.new_stock, message: 'Stock actualizado con éxito' });
  } catch (err) { next(err); }
};