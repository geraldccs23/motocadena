const { supabase } = require('../../services/supabaseClient');
const fs = require('fs');
const path = require('path');

function makeError(status, message, code = 'BAD_REQUEST') {
  const e = new Error(message);
  e.status = status;
  e.code = code;
  return e;
}

function logDetailedError(label, err) {
  const logPath = path.join(process.cwd(), 'backend_error.log');
  const errObject = {};
  if (err) {
    Object.getOwnPropertyNames(err).forEach(key => {
      errObject[key] = err[key];
    });
  }
  const logContent = `\n[${new Date().toISOString()}] ${label}: ${JSON.stringify(errObject, null, 2)}\n`;
  fs.appendFileSync(logPath, logContent);
  console.error(label, err);
}

exports.getCurrentSession = async (req, res, next) => {
  try {
    const { data: workshops, error: wsError } = await supabase.from('workshops').select('id').limit(1);
    if (wsError) throw makeError(500, 'Error buscando taller: ' + wsError.message);
    
    const ws = workshops?.[0];
    if (!ws) throw makeError(400, 'No hay taller configurado en la base de datos (Tabla workshops vacía)');

    const { data: session, error: sErr } = await supabase
      .from('cash_sessions')
      .select('*')
      .eq('workshop_id', ws.id)
      .eq('status', 'OPEN')
      .maybeSingle();

    if (sErr) {
      logDetailedError('Error buscando sesión de caja', sErr);
      throw makeError(500, 'Error buscando sesión de caja: ' + sErr.message);
    }

    if (!session) {
      return res.json({ ok: true, is_open: false, session: null });
    }

    if (req.query.with_stats === 'true') {
      let paymentsData = [];
      const { data: p1, error: e1 } = await supabase
        .from('payments')
        .select('*')
        .gte('created_at', session.opened_at);

      if (!e1) {
        paymentsData = p1 || [];
      } else {
        const { data: p2, error: e2 } = await supabase
          .from('pos_sale_payments')
          .select('*')
          .gte('created_at', session.opened_at);
        if (!e2) paymentsData = p2 || [];
      }

      let calcUsd = Number(session.opening_balance_usd);
      let calcBs = Number(session.opening_balance_bs);
      
      let breakdown = {
        EFECTIVO_USD: 0,
        EFECTIVO_BS: 0,
        PAGO_MOVIL: 0,
        TRANSFERENCIA_BS: 0,
        CREDITO: 0
      };

      paymentsData.forEach(p => {
        let usdMonto = Number(p.amount) || 0;
        let method = p.method || 'UNKNOWN';
        if (method === 'EFECTIVO_USD') calcUsd += usdMonto;
        if (breakdown[method] !== undefined) breakdown[method] += usdMonto;
        else breakdown[method] = usdMonto;
      });

      return res.json({
         ok: true, 
         is_open: true, 
         session: {
            ...session,
            live_calculated_usd: calcUsd,
            live_calculated_bs: calcBs,
            breakdown_usd: breakdown
         }
      });
    }

    res.json({ ok: true, is_open: true, session });
  } catch (err) { next(err); }
};

exports.openSession = async (req, res, next) => {
  try {
    let { opening_balance_usd, opening_balance_bs, opened_by } = req.body;
    
    const { data: workshops } = await supabase.from('workshops').select('id').limit(1);
    const ws = workshops?.[0];
    if (!ws) throw makeError(400, 'Taller no encontrado');

    const { data: existing, error: e1 } = await supabase
      .from('cash_sessions')
      .select('id')
      .eq('workshop_id', ws.id)
      .eq('status', 'OPEN')
      .maybeSingle();
      
    if (e1) {
      logDetailedError('Error validando sesión existente', e1);
      throw makeError(500, 'Error validando sesión existente: ' + e1.message);
    }
    if (existing) throw makeError(400, 'Ya existe un turno abierto para este taller.');

    const { data, error: iErr } = await supabase.from('cash_sessions').insert([{
      workshop_id: ws.id,
      opened_by: opened_by || null,
      opening_balance_usd: opening_balance_usd || 0,
      opening_balance_bs: opening_balance_bs || 0,
      status: 'OPEN'
    }]).select().maybeSingle();

    if (iErr) {
      logDetailedError('Error insertando sesión', iErr);
      throw makeError(500, 'Error insertando sesión: ' + (iErr.message || iErr.code || JSON.stringify(iErr)));
    }
    
    res.status(201).json({ ok: true, session: data });
  } catch (err) { next(err); }
};

exports.closeSession = async (req, res, next) => {
  try {
    const {
      session_id,
      closed_by,
      calculated_usd,
      calculated_bs,
      declared_usd,
      declared_bs,
      breakdown,
      closing_notes
    } = req.body;

    if (!session_id) throw makeError(400, 'session_id es requerido');

    const diffUsd = Math.abs(Number(calculated_usd) - Number(declared_usd));
    if (diffUsd > 0.50 && (!closing_notes || closing_notes.trim().length < 5)) {
       throw makeError(400, 'Has reportado un balance físico DIFERENTE al del sistema. DEBES escribir una justificación válida en las notas de cierre obligatoriamente.');
    }

    const { data, error } = await supabase.from('cash_sessions').update({
       closed_at: new Date().toISOString(),
       closed_by: closed_by,
       calculated_usd: calculated_usd,
       calculated_bs: calculated_bs,
       declared_usd: declared_usd,
       declared_bs: declared_bs,
       breakdown: breakdown,
       closing_notes: closing_notes,
       status: 'CLOSED'
    }).eq('id', session_id).select().maybeSingle();

    if (error) {
      logDetailedError('Error cerrando sesión', error);
      throw makeError(500, 'Error cerrando sesión: ' + error.message);
    }
    res.json({ ok: true, session: data });
  } catch (err) { next(err); }
};
