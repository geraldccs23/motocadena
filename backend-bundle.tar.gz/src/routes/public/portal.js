const express = require('express');
const router = express.Router();
const portalController = require('../../controllers/public/portalController');

// Ruta principal de inicio de sesión y sincronización del dashboard del cliente
router.post('/login', portalController.loginAndFetch);

module.exports = router;
