const express = require('express');
const router = express.Router();
const controller = require('../../controllers/admin/cashSessionController');

router.get('/current', controller.getCurrentSession);
router.post('/open', controller.openSession);
router.post('/close', controller.closeSession);

module.exports = router;
